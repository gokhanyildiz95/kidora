import request from 'supertest';
import { createApp } from '../src/app';
import { DEMO_PASSWORD } from '../src/seed-data';

export const app = createApp();

export async function loginAs(email: string) {
  const agent = request.agent(app);
  const res = await agent.post('/api/auth/login').send({ email, password: DEMO_PASSWORD });
  if (res.status !== 200) throw new Error(`login failed for ${email}: ${res.status}`);
  return agent;
}
